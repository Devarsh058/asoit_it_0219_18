function validate() {
  var name = document.forms["frm"]["name"].value;
  var email= document.forms["frm"]["email"].value;
  var message = document.forms["frm"]["message"].value;

if (name == ""|| email ==""|| message=="") {
    alert("Please fill all the fields")
    return false;
}
}